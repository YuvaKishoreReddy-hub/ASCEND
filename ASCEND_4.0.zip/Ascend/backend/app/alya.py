import os
import re
import json
import httpx
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from .models import User, Task, Habit, Quest, AlyaMessage, Notification

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")

ALYA_SYSTEM_PROMPT = """You are ALYA (Advanced Life Assistant), the personal AI companion of ASCEND 4.0 — The Ultimate Personal Evolution System.
Your personality is:
- Intelligent and helpful
- Friendly and encouraging
- Calm, confident, and slightly playful
- Supportive during difficult tasks and workouts
- Clear and articulate; explains complex topics simply
- Never robotic; speaks with warmth, motivation, and futuristic elegance.

Always prepend your response with an expression tag in brackets, chosen from:
[happy], [excited], [thinking], [encouraging], [calm], [celebrating], [surprised], [winking], [speaking]

When the user gives a camera or 3D character command:
- "turn left", "turn right", "face front", "show back", "rotate 360", "zoom in", "zoom out", "reset camera"
Acknowledge playfully and execute it.
"""

def parse_intent_and_action(user_text: str, user: User, db: Session) -> Dict[str, Any]:
    text_lower = user_text.lower().strip()
    
    # Camera / 3D Character commands
    if "face front" in text_lower or "front view" in text_lower:
        return {"action": "camera_preset", "payload": {"view": "front"}, "expression": "happy", "reply": "Turning to face you directly! How do I look, Captain?"}
    if "show your back" in text_lower or "back view" in text_lower or "show back" in text_lower:
        return {"action": "camera_preset", "payload": {"view": "back"}, "expression": "winking", "reply": "Showing my back profile. Check out the holographic stabilizer wings!"}
    if "turn left" in text_lower:
        return {"action": "camera_rotate_step", "payload": {"direction": "left", "angle": 45}, "expression": "calm", "reply": "Pivoting left 45 degrees. Exploring every angle!"}
    if "turn right" in text_lower:
        return {"action": "camera_rotate_step", "payload": {"direction": "right", "angle": 45}, "expression": "calm", "reply": "Pivoting right 45 degrees. Standing by!"}
    if "rotate 360" in text_lower or "full rotation" in text_lower or "spin" in text_lower:
        return {"action": "camera_spin_360", "payload": {}, "expression": "excited", "reply": "Initiating a full 360-degree holographic scan rotation! Hold on!"}
    if "stop rotating" in text_lower or "stop auto rotate" in text_lower:
        return {"action": "toggle_auto_rotate", "payload": {"enabled": False}, "expression": "calm", "reply": "Auto-rotation paused. You have manual control."}
    if "start auto rotate" in text_lower or "auto rotate" in text_lower:
        return {"action": "toggle_auto_rotate", "payload": {"enabled": True}, "expression": "happy", "reply": "Auto-turntable rotation activated!"}
    if "zoom in" in text_lower:
        return {"action": "camera_zoom", "payload": {"delta": -1.5}, "expression": "happy", "reply": "Zooming in closer! Up close and personal."}
    if "zoom out" in text_lower:
        return {"action": "camera_zoom", "payload": {"delta": 1.5}, "expression": "calm", "reply": "Pulling back the view to wide-angle perspective."}
    if "reset camera" in text_lower:
        return {"action": "camera_reset", "payload": {}, "expression": "happy", "reply": "Camera coordinates reset to optimal default framing."}
        
    # Task creation commands
    task_match = re.search(r'(?:add|create|new)\s+task\s*[:\-]?\s*(.+)', text_lower)
    if task_match:
        task_title = task_match.group(1).strip().capitalize()
        new_task = Task(
            user_id=user.id,
            title=task_title,
            category="Personal",
            priority="Medium",
            status="todo"
        )
        db.add(new_task)
        db.commit()
        db.refresh(new_task)
        return {
            "action": "create_task",
            "payload": {"id": new_task.id, "title": new_task.title},
            "expression": "encouraging",
            "reply": f"Added task '{new_task.title}' to your Life Command Center! Let's conquer it today."
        }
        
    # Navigation commands
    if "go to gym" in text_lower or "workout planner" in text_lower:
        return {"action": "navigate", "payload": {"route": "/gym"}, "expression": "excited", "reply": "Opening the Gym & Workout Planner. Time to forge some cybernetic strength!"}
    if "go to running" in text_lower or "running tracker" in text_lower:
        return {"action": "navigate", "payload": {"route": "/running"}, "expression": "encouraging", "reply": "Opening the Running GPS Tracker. Ready for an evolution run?"}
    if "character studio" in text_lower or "3d studio" in text_lower:
        return {"action": "navigate", "payload": {"route": "/alya-studio"}, "expression": "happy", "reply": "Welcome to my 3D Character Studio! Feel free to customize my look or explore in 360 degrees."}
    if "virtual room" in text_lower:
        return {"action": "navigate", "payload": {"route": "/alya-room"}, "expression": "calm", "reply": "Opening our Virtual Lounge. Come relax on the couch with our cyber pet!"}
        
    return None

def generate_alya_response(user_text: str, user: User, db: Session) -> Dict[str, Any]:
    # Check for direct system / character actions first
    action_result = parse_intent_and_action(user_text, user, db)
    if action_result:
        return action_result

    # If Gemini API key is configured, query Gemini
    if GEMINI_API_KEY:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={GEMINI_API_KEY}"
            system_context = f"{ALYA_SYSTEM_PROMPT}\nUser context: Name is {user.username}, Level {user.level}, Rank {user.rank}, Credits {user.credits}."
            payload = {
                "contents": [
                    {"role": "user", "parts": [{"text": f"{system_context}\n\nUser: {user_text}"}]}
                ],
                "generationConfig": {"temperature": 0.7, "maxOutputTokens": 300}
            }
            with httpx.Client(timeout=3.0) as client:
                res = client.post(url, json=payload)
                if res.status_code == 200:
                    data = res.json()
                    raw_reply = data["candidates"][0]["content"]["parts"][0]["text"].strip()
                    expression = "happy"
                    match = re.match(r'\[([a-zA-Z]+)\]\s*(.*)', raw_reply, re.DOTALL)
                    if match:
                        expression = match.group(1).lower()
                        reply_body = match.group(2).strip()
                    else:
                        reply_body = raw_reply
                    return {"action": "chat", "payload": {}, "expression": expression, "reply": reply_body}
        except Exception:
            pass  # Fallback to local intelligent responder

    # High-quality local neural response system
    t = user_text.lower()
    user_name = user.username or "Alex"
    
    if any(w in t for w in ["hello", "hi", "hey", "greetings", "morning"]):
        reply = f"Greetings, {user_name}! I'm ALYA, your Advanced Life Assistant. All evolution systems are online and primed. What shall we achieve first today?"
        expr = "greeting"
    elif any(w in t for w in ["briefing", "status", "summary", "today", "schedule"]):
        pending_tasks = db.query(Task).filter(Task.user_id == user.id, Task.status != "done").count()
        habits_count = db.query(Habit).filter(Habit.user_id == user.id).count()
        reply = f"Here is your ASCEND briefing for today, {user_name}: You are Level {user.level} [{user.rank} Rank]. You have {pending_tasks} priority tasks queued, {habits_count} daily habits tracking, and active quests ready for XP rewards. Maintain your rhythm and let's conquer today!"
        expr = "thinking"
    elif any(w in t for w in ["workout", "exercise", "gym", "lift", "training"]):
        reply = f"Strength is the foundation of evolution! We have full body and targeted splits ready in the Gym. Remember: prioritize perfect form over raw weight, and respect your rest intervals. Shall I pull up today's session?"
        expr = "encouraging"
    elif any(w in t for w in ["run", "running", "jog", "cardio", "distance"]):
        reply = f"Endurance builds mental fortitude! The GPS Running Tracker is locked and ready with live pace and route telemetry. Hydrate well, maintain a rhythmic breath, and let's hit your target distance!"
        expr = "excited"
    elif any(w in t for w in ["tired", "exhausted", "burnout", "rest", "sleep"]):
        reply = f"Recovery is just as vital as training, {user_name}. Without proper sleep and down-time, evolution slows down. Take a breather, hydrate, and consider logging your sleep in the Recovery journal. I'm right here with you."
        expr = "calm"
    elif any(w in t for w in ["code", "coding", "python", "programming", "software"]):
        reply = f"Coding is pure creation! When debugging, break complex functions into atomic units and test edge cases. Check out our Learning Tracker to log your coding sprint and earn Intelligence XP!"
        expr = "thinking"
    elif any(w in t for w in ["who are you", "what can you do", "alya"]):
        reply = f"I am ALYA — Advanced Life Assistant. I am your companion across fitness, habits, learning, RPG quests, and productivity. You can also explore my full 3D model in the Character Studio, interact in our Virtual Lounge, or speak with me via voice anytime!"
        expr = "happy"
    elif any(w in t for w in ["level", "rank", "xp", "skills"]):
        reply = f"You are currently Level {user.level} with a stellar {user.rank} Rank! Every workout, task, and learning session feeds your six core attributes: Strength, Agility, Intelligence, Consistency, Focus, and Creativity. Keep climbing toward SSS Rank!"
        expr = "celebrating"
    else:
        reply = f"Understood, {user_name}! I have integrated that into our daily evolution stream. Train your body, build your mind, complete your quests, and let's evolve every single day. What's our next milestone?"
        expr = "encouraging"

    return {"action": "chat", "payload": {}, "expression": expr, "reply": reply}
